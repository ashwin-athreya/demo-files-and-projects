package org.acme;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;

import java.util.Properties;

public class AverageSalesCalculator {

    public static void main(String[] args) {
        Properties config = new Properties();
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, "average-sales-calculator");
        config.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        StreamsBuilder builder = new StreamsBuilder();

        KStream<String, String> salesStream = builder.stream("joined_sales_product_customer_topic", Consumed.with(Serdes.String(), Serdes.String()));

        salesStream.mapValues(value -> {
                    // Parse the sales order
                    String productId = value.split("\"product_id\": \"")[1].split("\"")[0];
                    double quantity = Double.parseDouble(value.split("\"quantity\": \"")[1].split("\"")[0]);
                    double price = Double.parseDouble(value.split("\"price\": \"")[1].split("\"")[0]);

                    // Calculate the total sales amount
                    double salesAmount = quantity * price;

                    return String.valueOf(salesAmount);
                }).groupByKey(Grouped.with(Serdes.String(), Serdes.String()))
                .aggregate(
                        () -> new TotalSalesAmountAndCount(0.0, 0),
                        (key, value, aggregate) -> aggregate.addSalesAmountAndIncrementCount(Double.parseDouble(value)),
                        Materialized.as("average-sales-store")
                )
                .toStream()
                .mapValues(AverageSalesCalculator::calculateAverageSalesAndRevenue)
                .to("average_sales_topic", Produced.with(Serdes.String(), Serdes.String()));

        KafkaStreams streams = new KafkaStreams(builder.build(), config);
        streams.start();

        // Shutdown hook to gracefully close the streams application
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
    }

    public static class TotalSalesAmountAndCount {
        private double totalSalesAmount;
        private int count;

        public TotalSalesAmountAndCount(double totalSalesAmount, int count) {
            this.totalSalesAmount = totalSalesAmount;
            this.count = count;
        }

        public TotalSalesAmountAndCount addSalesAmountAndIncrementCount(double salesAmount) {
            totalSalesAmount += salesAmount;
            count++;
            return this;
        }
    }

    public static String calculateAverageSalesAndRevenue(TotalSalesAmountAndCount aggregate) {
        double averageSales = aggregate.totalSalesAmount / aggregate.count;
        double averageRevenue = aggregate.totalSalesAmount;
        return String.valueOf(averageSales) + "," + String.valueOf(averageRevenue);
    }
}
