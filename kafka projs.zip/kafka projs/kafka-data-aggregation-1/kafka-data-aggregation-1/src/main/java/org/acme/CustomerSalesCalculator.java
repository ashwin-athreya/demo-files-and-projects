package org.acme;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Grouped;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;

import java.util.Properties;

public class CustomerSalesCalculator {

    public static void main(String[] args) {
        Properties config = new Properties();
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, "customer-sales-calculator");
        config.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        StreamsBuilder builder = new StreamsBuilder();

        KStream<String, String> salesStream = builder.stream("joined_sales_product_customer_topic", Consumed.with(Serdes.String(), Serdes.String()));

        salesStream.map((key, value) -> {
                    // Parse the sales order
                    String customerId = value.split("\"customer_id\": \"")[1].split("\"")[0];
                    int quantity = Integer.parseInt(value.split("\"quantity\": \"")[1].split("\"")[0]);
                    double price = Double.parseDouble(value.split("\"price\": \"")[1].split("\"")[0]);

                    // Calculate total sales and total revenue
                    double totalSales = quantity;
                    double totalRevenue = quantity * price;

                    // Prepare the result string
                    return KeyValue.pair(customerId, "{\"total_sales\": \"" + totalSales + "\", \"total_revenue\": \"" + totalRevenue + "\"}");
                }).groupByKey(Grouped.with(Serdes.String(), Serdes.String()))
                .reduce((value1, value2) -> {
                    // Parse the total sales and total revenue from the values
                    double totalSales1 = Double.parseDouble(value1.split("\"total_sales\": \"")[1].split("\"")[0]);
                    double totalSales2 = Double.parseDouble(value2.split("\"total_sales\": \"")[1].split("\"")[0]);
                    double totalRevenue1 = Double.parseDouble(value1.split("\"total_revenue\": \"")[1].split("\"")[0]);
                    double totalRevenue2 = Double.parseDouble(value2.split("\"total_revenue\": \"")[1].split("\"")[0]);

                    // Calculate the aggregated total sales and total revenue
                    double totalSales = totalSales1 + totalSales2;
                    double totalRevenue = totalRevenue1 + totalRevenue2;

                    // Prepare the result string
                    return "{\"total_sales\": \"" + totalSales + "\", \"total_revenue\": \"" + totalRevenue + "\"}";
                }, Materialized.as("customer-sales-store"))
                .toStream()
                .to("customer_sales_topic", Produced.with(Serdes.String(), Serdes.String()));

        KafkaStreams streams = new KafkaStreams(builder.build(), config);
        streams.start();

        // Shutdown hook to gracefully close the streams application
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
    }
}
