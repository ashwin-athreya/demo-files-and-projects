//package org.acme;
//
//public class TotalQuantityAndCount {
//    private String totalQuantity;
//    private int count;
//
//    public TotalQuantityAndCount(String totalQuantity, int count) {
//        this.totalQuantity = totalQuantity;
//        this.count = count;
//    }
//
//    public TotalQuantityAndCount addQuantityAndIncrementCount(String quantity) {
//        int parsedQuantity = Integer.parseInt(quantity);
//        int newTotalQuantity = Integer.parseInt(totalQuantity) + parsedQuantity;
//        return new TotalQuantityAndCount(String.valueOf(newTotalQuantity), count + 1);
//    }
//
//    public String calculateAverageAsString() {
//        int parsedTotalQuantity = Integer.parseInt(totalQuantity);
//        double average = parsedTotalQuantity / (double) count;
//        return String.valueOf(average);
//    }
//}
