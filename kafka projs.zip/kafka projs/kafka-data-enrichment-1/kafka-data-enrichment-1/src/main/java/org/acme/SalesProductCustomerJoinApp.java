package org.acme;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Joined;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.kstream.GlobalKTable;

import java.util.Properties;

public class SalesProductCustomerJoinApp {

    public static void main(String[] args) {
        Properties config = new Properties();
        config.put(StreamsConfig.APPLICATION_ID_CONFIG, "sales-product-customer-join-app");
        config.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        StreamsBuilder builder = new StreamsBuilder();

        KStream<String, String> salesStream = builder.stream("sales_topic", Consumed.with(Serdes.String(), Serdes.String()));
        GlobalKTable<String, String> customerTable = builder.globalTable("customer_topic", Materialized.with(Serdes.String(), Serdes.String()));
        GlobalKTable<String, String> productTable = builder.globalTable("product_topic", Materialized.with(Serdes.String(), Serdes.String()));

        KStream<String, String> joinedStream = salesStream
                .leftJoin(customerTable,
                        (salesKey, salesValue) -> salesValue.split("\"customer_id\": \"")[1].split("\"")[0],
                        (salesValue, customerValue) -> "Sales: " + salesValue + ", Customer: " + (customerValue != null ? customerValue : "No customer data found"))
                .leftJoin(productTable,
                        (salesKey, salesValue) -> salesValue.split("\"product_id\": \"")[1].split("\"")[0],
                        (salesValue, productValue) -> salesValue + ", Product: " + (productValue != null ? productValue : "No product data found"));

        joinedStream.to("joined_sales_product_customer_topic", Produced.with(Serdes.String(), Serdes.String()));

        KafkaStreams streams = new KafkaStreams(builder.build(), config);
        streams.start();

        // Shutdown hook to gracefully close the streams application
        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
    }
}
