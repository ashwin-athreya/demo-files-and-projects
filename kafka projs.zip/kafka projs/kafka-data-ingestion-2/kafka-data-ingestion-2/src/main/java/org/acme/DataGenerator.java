package org.acme;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.util.Properties;

public class DataGenerator {
    private static final String BOOTSTRAP_SERVERS = "localhost:9092";
    private static final String SALES_TOPIC = "sales_topic";
    private static final String CUSTOMER_TOPIC = "customer_topic";
    private static final String PRODUCT_TOPIC = "product_topic";

    private static final String[] PRODUCT_IDS = {"1", "2", "3", "4", "5"};
    private static final String[] PRODUCT_NAMES = {"Java Book", "Python Book", "C++ Book", "Data Structures Book", "Algorithms Book"};
    private static final int[] PRODUCT_PRICES = {50, 60, 70, 80, 90}; // Prices associated with each product

    private static final String[] CUSTOMER_IDS = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20"};
    private static final String[] LOCATIONS = {"Bangalore", "Mumbai", "Delhi", "Hyderabad", "Chennai"};
    private static final int[] AGES = {20, 25, 30, 35, 40};
    private static final String[] GENDERS = {"Male", "Female"};

    private static final int NUM_PRODUCTS = 5;
    private static final int NUM_CUSTOMERS = 20;
    private static final int NUM_SALES = 100;

    public static void main(String[] args) {
        // Kafka producer configuration
        Properties props = new Properties();
        props.put("bootstrap.servers", BOOTSTRAP_SERVERS);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        try (Producer<String, String> producer = new KafkaProducer<>(props)) {
            generateAndPublishSalesData(producer);
            generateAndPublishCustomerData(producer);
            generateAndPublishProductData(producer);
        }
    }

    private static void generateAndPublishSalesData(Producer<String, String> producer) {
        for (int i = 0; i < NUM_SALES; i++) {
            String order_id = String.valueOf(i + 1);
            String product_id = PRODUCT_IDS[i % NUM_PRODUCTS]; // Loop through product IDs
            String customer_id = CUSTOMER_IDS[i % NUM_CUSTOMERS]; // Loop through customer IDs
            String quantity = String.valueOf(getRandomQuantity());

            String saleData = "{\"product_id\": \"" + product_id + "\", \"customer_id\": \"" + customer_id + "\", \"quantity\": \"" + quantity + "\"}";
            producer.send(new ProducerRecord<>(SALES_TOPIC, order_id, saleData));
        }
    }

    private static void generateAndPublishCustomerData(Producer<String, String> producer) {
        for (int i = 0; i < NUM_CUSTOMERS; i++) {
            String customer_id = CUSTOMER_IDS[i];
            String location = LOCATIONS[i % LOCATIONS.length]; // Loop through locations
            String age = String.valueOf(AGES[i % AGES.length]); // Loop through ages
            String gender = GENDERS[i % GENDERS.length]; // Loop through genders

            String customerData = "{\"location\": \"" + location + "\", \"age\": \"" + age + "\", \"gender\": \"" + gender + "\"}";
            producer.send(new ProducerRecord<>(CUSTOMER_TOPIC, customer_id, customerData));
        }
    }

    private static void generateAndPublishProductData(Producer<String, String> producer) {
        for (int i = 0; i < NUM_PRODUCTS; i++) {
            String product_id = PRODUCT_IDS[i];
            String product_name = PRODUCT_NAMES[i];
            int price = PRODUCT_PRICES[i];

            String productData = "{\"product_name\": \"" + product_name + "\", \"price\": \"" + price + "\"}";
            producer.send(new ProducerRecord<>(PRODUCT_TOPIC, product_id, productData));
        }
    }

    private static int getRandomQuantity() {
        return (int) (Math.random() * 10) + 1;
    }
}
